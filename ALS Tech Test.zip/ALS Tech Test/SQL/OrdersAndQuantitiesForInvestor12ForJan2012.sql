SELECT
	investor_id,
	fund_name,
	COUNT(0) as order_count,
	SUM(quantity) as order_quantity
FROM
	orders o 
INNER JOIN
	funds f
ON
	f.fund_id = o.fund_id
WHERE
	investor_id = 12
AND	order_date LIKE '2012-01-%'
GROUP BY
	o.investor_id,
	f.fund_name
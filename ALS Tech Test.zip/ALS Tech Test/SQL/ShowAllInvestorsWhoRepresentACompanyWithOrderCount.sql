SELECT 
	(TRIM(forename) + ' ' + TRIM(surname)) as mail_name,
	business_name,
	COUNT(order_id) as order_count
FROM
	investors
LEFT JOIN
	orders
ON 
	orders.investor_id = investors.investor_id
WHERE
	business_name IS NOT NULL
GROUP BY
	(TRIM(forename) + ' ' + TRIM(surname)),
	business_name
SELECT TOP 3
	order_id,
	(quantity * price) as VALUE
FROM 
	orders
ORDER BY
	VALUE
DESC
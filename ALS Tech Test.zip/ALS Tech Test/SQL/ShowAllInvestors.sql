SELECT 
	* 
FROM 
	investors
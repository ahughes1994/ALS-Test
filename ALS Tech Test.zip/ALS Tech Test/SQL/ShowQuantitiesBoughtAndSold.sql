SELECT
	buy_sell,
	SUM(quantity) as total_quantity
FROM
	orders
GROUP BY
	buy_sell
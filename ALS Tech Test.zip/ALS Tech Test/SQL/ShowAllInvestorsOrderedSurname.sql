SELECT 
	* 
FROM	
	investors 
ORDER BY 
	surname
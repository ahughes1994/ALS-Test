SELECT 
	(TRIM(forename) + ' ' + TRIM(surname)) as mail_name,
	business_name
FROM
	investors
where
	business_name IS NOT NULL
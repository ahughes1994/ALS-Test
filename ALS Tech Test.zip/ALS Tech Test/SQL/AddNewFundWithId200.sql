  INSERT INTO funds (fund_id, fund_name)
  VALUES (200, 'TEST FUND')
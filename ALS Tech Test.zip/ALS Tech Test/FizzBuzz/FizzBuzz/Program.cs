﻿using System;

namespace FizzBuzz
{
    class Program
    {
        static void Main(string[] args)
        {
            var input = Console.ReadLine();

            while(!string.IsNullOrEmpty(input))
            {
                if (int.TryParse(input, out var result))
                {
                    var output = string.Empty;

                    if (result % 3 == 0)
                    {
                        output += "Fizz";
                        
                        if (result % 5 == 0)
                        {
                            output += " Buzz";
                        }
                    }
                    else if (result % 5 == 0)
                    {
                        output += "Buzz";
                    }
                    else
                    {
                        output += input;
                    }

                    Console.WriteLine(output);
                }
                else
                {
                    Console.WriteLine("Please enter a valid integer.");
                }

                input = Console.ReadLine();
            }
        }
    }
}

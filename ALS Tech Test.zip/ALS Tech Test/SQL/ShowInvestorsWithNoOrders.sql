SELECT
	investors.investor_id,
	forename,
	surname,
	business,
	business_name,
	active
FROM
	investors
INNER JOIN
	orders
ON
	orders.investor_id = investors.investor_id
GROUP BY
	investors.investor_id,
	forename,
	surname,
	business,
	business_name,
	active